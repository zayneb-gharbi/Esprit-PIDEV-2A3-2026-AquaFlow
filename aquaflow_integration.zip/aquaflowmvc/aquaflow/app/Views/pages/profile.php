<?php
// Views/pages/profile.php : informations personnelles (HTML pur)
// variables : $user, $roleLabel
?>
<div class="card narrow">
    <h1>Bienvenue, <?= e($user['prenom']) ?></h1>
    <span class="badge"><?= e($roleLabel) ?></span>

    <table class="info">
        <tr><th>Prénom</th><td><?= e($user['prenom']) ?></td></tr>
        <tr><th>Nom</th><td><?= e($user['nom']) ?></td></tr>
        <tr><th>E-mail</th><td><?= e($user['email']) ?></td></tr>
        <tr><th>Téléphone</th><td><?= e($user['telephone']) ?></td></tr>
        <?php if ($user['role'] == 'P') { ?>
            <tr><th>Zone de service</th><td><?= e($user['zone_service'] ?? '') ?></td></tr>
            <tr><th>Expérience</th><td><?= e($user['experience'] ?? '') ?> ans</td></tr>
        <?php } ?>
        <tr><th>Membre depuis</th><td><?= e($user['date_creation'] ?? '') ?></td></tr>
    </table>
</div>
