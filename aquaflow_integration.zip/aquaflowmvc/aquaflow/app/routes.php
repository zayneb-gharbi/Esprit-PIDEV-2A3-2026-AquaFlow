<?php
// routes.php : cle de page  ->  controller
$routes = [
    'signin'  => 'SigninController',
    'signup'  => 'SignupController',
    'profile' => 'ProfileController',
    'admin'   => 'AdminController',
    'stats'     => 'StatsController',
    'citoyens'  => 'CitoyensController',
    'plombiers' => 'PlombiersController',
    'logout'  => 'LogoutController',
];
