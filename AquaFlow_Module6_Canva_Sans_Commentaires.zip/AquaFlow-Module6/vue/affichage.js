function ajouterElement(parent, balise) {
    const element = document.createElement(balise);
    parent.appendChild(element);
    return element;
}

function afficherSolde(total, gain) {
    document.getElementById("total").textContent = total;
    document.getElementById("gain").textContent = "+" + gain + " points ce mois-ci";
}

function afficherCarte(recompense) {
    const offres = document.getElementById("offres");
    const carte = ajouterElement(offres, "article");
    carte.className = "produit";

    const photo = ajouterElement(carte, "div");
    photo.className = "photo";
    const image = ajouterElement(photo, "img");
    image.src = "images/" + recompense.photo;
    image.alt = "";

    const fiche = ajouterElement(carte, "div");
    fiche.className = "fiche";

    const nom = ajouterElement(fiche, "h3");
    nom.textContent = recompense.nom;

    const cout = ajouterElement(fiche, "p");
    cout.className = "cout";
    cout.textContent = recompense.cout + " points";

    const disponibilite = ajouterElement(fiche, "p");
    disponibilite.className = "dispo";
    disponibilite.textContent = "Disponible";
}

function afficherOperation(operation) {
    const historique = document.getElementById("operations");
    const ligne = ajouterElement(historique, "li");
    const motif = ajouterElement(ligne, "span");
    const montant = ajouterElement(ligne, "strong");

    motif.textContent = operation.motif;
    if (operation.points < 0) {
        montant.className = "moins";
        montant.textContent = "−" + Math.abs(operation.points) + " pts";
    } else {
        montant.className = "plus";
        montant.textContent = "+" + operation.points + " pts";
    }
}

function afficherLigne(recompense) {
    const tableau = document.getElementById("catalogue");
    const ligne = ajouterElement(tableau, "tr");

    const nom = ajouterElement(ligne, "th");
    nom.scope = "row";
    nom.textContent = recompense.nom;

    const cout = ajouterElement(ligne, "td");
    cout.textContent = recompense.cout + " pts";

    const stock = ajouterElement(ligne, "td");
    stock.textContent = recompense.stock;
}

function afficherIndicateurs(nombreRecompenses, nombreOffres, stockTotal) {
    document.getElementById("nombre-catalogue").textContent = nombreRecompenses;
    document.getElementById("nombre-offres").textContent = nombreOffres;
    document.getElementById("stock-total").textContent = stockTotal;
}
