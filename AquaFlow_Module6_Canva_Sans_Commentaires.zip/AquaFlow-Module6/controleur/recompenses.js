if (document.body.id === "citoyen") {
    afficherSolde(solde, gainDuMois);

    for (const recompense of offresCitoyen) {
        afficherCarte(recompense);
    }

    for (const operation of historique) {
        afficherOperation(operation);
    }
} else {
    for (const recompense of catalogue) {
        afficherLigne(recompense);
    }

    const stockTotal = calculerStockTotal();
    afficherIndicateurs(catalogue.length, offresCitoyen.length, stockTotal);
}
