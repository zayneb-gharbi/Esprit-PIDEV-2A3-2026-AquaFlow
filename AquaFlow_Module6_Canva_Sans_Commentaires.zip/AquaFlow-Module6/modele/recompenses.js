const solde = 450;
const gainDuMois = 50;

const gourde = {
    nom: "Gourde réutilisable",
    cout: 200,
    stock: 15,
    photo: "gourde.jpg"
};
const sac = {
    nom: "Sac écologique",
    cout: 300,
    stock: 20,
    photo: "sac.jpg"
};
const bon = {
    nom: "Bon d’achat",
    cout: 500,
    stock: 10
};

const offresCitoyen = [gourde, sac];
const catalogue = [gourde, sac, bon];

const historique = [
    { motif: "Économie d’eau", points: 50 },
    { motif: "Économie d’eau", points: 30 },
    { motif: "Échange de gourde", points: -200 }
];

function calculerStockTotal() {
    let total = 0;

    for (const recompense of catalogue) {
        total = total + recompense.stock;
    }

    return total;
}
