<?php
return [
    'dsn'      => 'oci:dbname=//127.0.0.1:1521/XE;charset=AL32UTF8',
    'username' => 'WEB',
    'password' => 'omarhermi69',
];