<?php
namespace App\Models;

use PDO;
use Exception;

class Model
{
    private static $pdo = null;

    public static function getConnexion()
    {
        if (!isset(self::$pdo)) {
            try {
                $cfg = require __DIR__ . '/../config.db.php';
                self::$pdo = new PDO(
                    $cfg['dsn'],
                    $cfg['username'],
                    $cfg['password'],
                    [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_CASE => PDO::CASE_LOWER
                    ]
                );
            } catch (Exception $e) {
                die('Erreur: ' . $e->getMessage());
            }
        }
        return self::$pdo;
    }
}